1.foodpanda folder is the PHP code which you need to keep in the location

C:\xampp\htdocs\

2.the zipped mysql file you need to import from the PHP web console

http://localhost:/phpmyadmin/
 and select the import option to browse the zipped file- foodpanda.sql
 

3.open http://localhost:/foodpanda
 
 to access the above site